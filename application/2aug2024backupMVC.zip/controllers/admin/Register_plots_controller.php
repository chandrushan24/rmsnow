<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_plots_controller extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        // $this->load->model('Property_model','property');
    }
    public function index($id = NULL)
	{
        $data                 = array();
        
        $data['title'] = 'Registered Plot';
        if(empty($id)){
            $data['get_seq'] = $this->common_model->get_single_date('autonumber','process',$data['title']);
            $current_seqno = $data['get_seq']['seqno'];
            $no_of_digit = $data['get_seq']['no_of_digit'];
            $prefix = $data['get_seq']['prefix'];
            $suffix = $data['get_seq']['suffix'];
            $new_seqno = $current_seqno + 1;
            $formatted_seqno = str_pad($new_seqno, $no_of_digit, '0', STR_PAD_LEFT);
            $data['seq_no'] = $formatted_seqno;
            $data['get_seq_no'] = $prefix . $formatted_seqno . $suffix;
        }
        if($id){
            $data['get_prop'] = $this->common_model->get_single_date('tbl_reg_plot','reg_plot_id',$id);
            $data['reg_plot_reg_title_deed']    = $this->common_model->get_media_img('reg_plot_reg_title_deed',$id,'','');
            $data['plot_sketch']    = $this->common_model->get_media_img('plot_sketch',$id,'','');
        }
        $data['propert_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_property');
        $data['all_employees'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_staff_info');

		$this->render_page('admin/property/registered_plot',$data); 
	}

    public function index_1($id)
	{
        $data                 = array();
        
        $data['title'] = 'Registered Plot';
            //  if(empty($id)){
            $data['get_seq'] = $this->common_model->get_single_date('autonumber','process',$data['title']);
            $current_seqno = $data['get_seq']['seqno'];
            $no_of_digit = $data['get_seq']['no_of_digit'];
            $prefix = $data['get_seq']['prefix'];
            $suffix = $data['get_seq']['suffix'];
            $new_seqno = $current_seqno + 1;
            $formatted_seqno = str_pad($new_seqno, $no_of_digit, '0', STR_PAD_LEFT);
            $data['seq_no'] = $formatted_seqno;
            $data['get_seq_no'] = $prefix . $formatted_seqno . $suffix;
        // }
        if($id){
            $data['get_prop_'] = $this->db->select('A.*, B.plot_detail_id,B.plot_no as plot_nos, B.plot_extension as plot_extensions, B.north as norths, B.east as easts, B.west as wests, B.south as souths')
            ->from('tbl_property as A')
            ->join('tbl_plot_details B', 'B.property_id = A.property_id', 'left')
            ->where('B.deleted', 0)
            ->where('A.deleted', 0)
            ->where('B.plot_detail_id', $id)
            ->get()
            ->row_array();

            // echo '<pre>';
            // print_r($data['get_prop_']);
            // die();
        }
        $data['propert_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_property');
        $data['all_employees'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_staff_info');

		$this->render_page('admin/property/registered_plot',$data); 
	}

    public function save_register_plot(){  
       
        $data                         = array();
        $reg_plot_id  = $this->input->post('reg_plot_id');
        $data['s_no'] =$this->input->post('s_no_input');
        $seqno  = $this->input->post('seqno');
        $data['property_name'] =$this->input->post('property_name_input');
        $data['plot_no'] =$this->input->post('plot_no_input');
        $data['total_plo_extension'] =$this->input->post('total_plo_extension_input');
        $data['buyer_name'] =$this->input->post('buyer_name_input');
        $data['buyer_gender'] =$this->input->post('buyer_gender_input');
        $data['father_rel'] =$this->input->post('father_rel_input');
        $data['phone_number'] =$this->input->post('phone_number_input');
        $data['buyer_address'] =$this->input->post('buyer_address_input');
        $data['father_name'] =$this->input->post('father_name_input');

        $data['east'] =$this->input->post('east_input');
        $data['west'] =$this->input->post('west_input');
        $data['north'] =$this->input->post('north_input');
        $data['south'] =$this->input->post('south_input');

        $data['id_proof_select'] =$this->input->post('id_proof_select_input');
        $data['id_proof'] =$this->input->post('id_proof_input');
        $data['plot_reg_doc_num'] =$this->input->post('plot_reg_doc_num');
        $data['plot_reg_date'] =$this->input->post('plot_reg_date_input');
      
        $data['patta_chitta'] =$this->input->post('patta_chitta_input');
        $data['t_s_no'] =$this->input->post('t_s_no_input');
        $data['ward_block'] =$this->input->post('ward_block_input');
       
        $data['plot_rate'] =$this->input->post('plot_rate_input');
        $data['mode_payment'] =$this->input->post('mode_payment_input');
        $data['mode_payment_value'] =$this->input->post('mode_payment_value_input');
        $implode_value = !empty($this->input->post('name_ref_by_input')) ? implode(',',$this->input->post('name_ref_by_input')) : '';
        $data['name_ref_by'] =$implode_value;
        // $data['name_ref_by'] =$this->input->post('name_ref_by_input');
        $data['alt_phone_number'] =$this->input->post('alt_phone_number_input');

        $data['reg_district'] =$this->input->post('reg_district_input');
        $data['reg_town_village'] =$this->input->post('reg_town_village_input');
        $data['reg_sub_district'] =$this->input->post('reg_sub_district_input');
        $data['reg_revenue_taluk'] =$this->input->post('reg_revenue_taluk_input');
        $data['sub_reg'] =$this->input->post('sub_reg_input');
        $data['customer_id'] =$this->input->post('customer_id');
        $data['user_id'] =$this->session->userdata('userid');
        $data['company_id'] = $this->session->userdata('comp_id');
        
         if(!empty($data['customer_id'])){
            $update=[
                // 'id' => $row['customer_info_id'],
                'buyer_name' => $data['buyer_name'],
                'street_address' => $data['buyer_address'],
                'id_proof_select' => $data['id_proof_select'],
                'id_proof' => $data['id_proof'],
                'phone_number_1' => $data['phone_number'],
                'id_proof' => $data['id_proof'],
                'father_rel' => $data['father_rel'],
                'father_name' => $data['father_name'],
                'buyer_gender' => $data['buyer_gender'],
            ];

            $this->db->where('customer_info_id',$data['customer_id']);
            $this->db->update('tbl_customer_info',$update);
         }
         if(!empty($data['plot_no'])){
            $data1['status'] = "Registered";
            $this->common_model->update_info('tbl_plot_details',$data1,'plot_detail_id',$data['plot_no']);
         }
            if($reg_plot_id == ''){
                $reg_plot_id = $this->common_model->save('tbl_reg_plot',$data);
                $this->common_model->update_info('autonumber',array('seqno' => $seqno),'process','Registered Plot');
                $status = 'Inserted';
            }else{
                $this->common_model->update_info('tbl_reg_plot',$data,'reg_plot_id',$reg_plot_id);
                $status = 'Updated';
            }
            
            $page_name = "Registered Plot";

            if ($reg_plot_id) {

            // echo  '<pre>';print_r($_FILES['reg_plot_reg_title_deed_doc_file_input']);die();
            if (!empty($_FILES['reg_plot_reg_title_deed_doc_file_input']['name'][0])) {
                common_file_upload('uploads/registered_plot/reg_plot_reg_title_deed_doc/','*','reg_plot_reg_title_deed_doc_file_input','reg_plot_reg_title_deed',$reg_plot_id,'reg_plot');
            }

            if (!empty($_FILES['plot_sketch_file_input']['name'][0])) {
                common_file_upload('uploads/registered_plot/plot_sketch/','*','plot_sketch_file_input','plot_sketch',$reg_plot_id,'reg_plot');
            }

                $page_name = "Registered Plot";
    
                $response = array('status' => 'success', 'message' => $page_name . ' '.$status.'  Successfully');
    
                } else {
                    $response = array('status' => 'error', 'message' => $page_name . ' '.$status.'  Failed');
                }
                
                echo json_encode($response);
                return;
    
    
    }

}