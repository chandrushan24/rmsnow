<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Unregistered_plots_controller extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        // $this->load->model('Property_model','property');
    }
    public function index($id = NULL)
	{
        $data                 = array();
    
        $data['title'] = 'Unregistered Plot';
            
        if($id){
            $data['get_prop'] = $this->common_model->get_single_date('tbl_unreg_plot','unreg_plot_id',$id);
        }

        $data['propert_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_property');

		$this->render_page('admin/property/unregistered_plots',$data); 
	}

    public function save_unregistered_plot()
    {
        $data                         = array();
        $unreg_plot_id  = $this->input->post('unreg_plot_id');
        $data['s_no'] =$this->input->post('s_no_input');
        $data['property_name'] =$this->input->post('property_name_input');
        $data['plot_no'] =$this->input->post('plot_no_input');
        $data['total_plot_extension'] =$this->input->post('total_plot_extension_input');
        $data['east'] =$this->input->post('east_input');
        $data['west'] =$this->input->post('west_input');
        $data['north'] =$this->input->post('north_input');
        $data['south'] =$this->input->post('south_input');
        $data['user_id'] =$this->session->userdata('userid');
        $data['company_id'] = $this->session->userdata('comp_id');
        
        if($unreg_plot_id == ''){
            $unreg_plot_id = $this->common_model->save('tbl_unreg_plot',$data);
            $status = 'Inserted';
        }else{
            $this->common_model->update_info('tbl_unreg_plot',$data,'unreg_plot_id',$unreg_plot_id);
            $status = 'Updated';
        }

      if ($unreg_plot_id) {

        $page_name = "Unregistered Plot";
        
        $response = array('status' => 'success', 'message' => $page_name . ' '.$status.'  Successfully');
    
    } else {
        $response = array('status' => 'error', 'message' => $page_name . ' '.$status.'  Failed');
    }
    
    echo json_encode($response);
    return;

    }


    public function get_plot_details() 
    {
    $property_id = $this->input->get('property_id');
    $status = $this->input->get('status');
    $data = $this->common_model->getall_record_info_with_detail_with_two_id_array('tbl_plot_details','property_id',$property_id,'status',$status);
    echo json_encode($data);
    return;
    }

    public function get_property_details()
    {
    $property_id = $this->input->get('property_id');
    $data = $this->common_model->get_single_date('tbl_property','property_id',$property_id);
    echo json_encode($data);
    return;
    }
    public function get_single_plot_details()
    {
    $detail_id = $this->input->get('detail_id');
    $data = $this->common_model->get_single_date('tbl_plot_details','plot_detail_id',$detail_id);
    echo json_encode($data);
    return;
    }

    
    public function get_property_files()
    {
    $property_id = $this->input->get('property_id');
    $module_type = $this->input->get('module_type');
    $data = $this->common_model->get_media_img($module_type,$property_id,'','');
    echo json_encode($data);
    return;
    }

    public function get_employee_details()
    {
    $emp_id = $this->input->get('emp_id');
    $data = $this->common_model->get_single_date('tbl_staff_info','staff_info_id',$emp_id);
    echo json_encode($data);
    return;
    }

    public function autocomplete() {
        $term = $this->input->get('term');
        $results = $this->common_model->search_customers($term);
        echo json_encode($results);
    }

    public function add_customer() {
        $customerName = $this->input->post('customerName');
        $customerId = $this->common_model->add_or_get_customer_id($customerName);
        echo json_encode(['id' => $customerId]);
    }
    
}
