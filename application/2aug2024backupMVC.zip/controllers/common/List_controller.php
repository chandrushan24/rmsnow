<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH.'libraries/tcpdf/tcpdf.php';

class List_controller extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('List_model','list');
        $this->load->library('tcpdf');
        // $this->load->library('Pdf');
    }
    public function index()
	{
        $current_url = $_SERVER['REQUEST_URI'];
        $url_parts = parse_url($current_url);
        $path_segments = explode('/', trim($url_parts['path'], '/'));
        $last_segment = end($path_segments);
        $data = array();
        $title = $last_segment;
        // if($title == 'reg_plot'){
        //     $data['title'] = 'Register Plotss';
        //     $data['page_name'] = $title;
        //     $table_name ='tbl_regplotss';
        //     $order_by ='reg_plots_id';
        // }
       
            $data['title'] = $title;
        
        // $data['next_order'] = $this->list->get_next_order($table_name , $data['title'],$order_by);
        // $data['record_list'] = $this->list->get_all_data($table_name , $data['title'],$order_by);
		$this->render_page('admin/list_page',$data); 
	}

    function get_list_data(){
        $draw = $this->input->get('draw');
        $start = $this->input->get('start');
        $length = $this->input->get('length');
        $search_value = $this->input->get('search[value]');
        $col = 0;
        $sort = "";
        $page_title = $this->input->get('title');

        $search_value = $this->input->get('search')['value']; 
        $table='';
        $uniq_id = '';
        $search_columns = array();

        if(!empty($page_title) && $page_title == 'Property'){
        $table='tbl_property';
        $uniq_id = 'property_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {

        $data[] = array(
            $no++,
            $val->property_id,
            $val->property_name,
            $val->village_town,
            $val->taluk_name,
            '<a class="btn btn-success btn-sm" data-id="'.$val->property_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->property_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<a class="btn btn-info btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->property_id.'/pdf" ><i class="ri-file-pdf-2-fill"></i></a>'.' '.
            '<a class="btn btn-secondary btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->property_id.'/print" ><i class="ri-printer-line"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->property_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'reg_plot'){
        $table='tbl_reg_plot';
        $uniq_id = 'reg_plot_id';
        $status ='sold';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        
        $data[] = array(
            $no++,
            $val->reg_plot_id,
            $property_name,
            $val->buyer_name, 
            $val->father_name,
            '<a class="btn btn-success btn-sm" data-id="'.$val->reg_plot_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->reg_plot_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<a class="btn btn-info btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->reg_plot_id.'/pdf" ><i class="ri-file-pdf-2-fill"></i></a>'.' '.
            '<a class="btn btn-secondary btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->reg_plot_id.'/print" ><i class="ri-printer-line"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->reg_plot_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'unreg_plot'){
        $table='tbl_plot_details';
        $uniq_id = 'plot_detail_id';
        $status = 'UnSold';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property_details($search_value,$table,$uniq_id,$status);
        $data1 = $this->list->get_property_details($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns,$status);
        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE deleted = 0 AND property_id = ?", array($val->property_id));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        $data[] = array(
            $no++,
            $val->plot_detail_id,
            $property_name,
            $val->plot_no, 
            $val->plot_extension,
            '<a class="btn btn-success btn-sm" data-id="'.$val->plot_detail_id .'" href="'.base_url().'Add_reg_plots/'.$val->plot_detail_id.'" style="border-radius: 25px;" >Register Plot</a>'.' '.
            '<a class="btn btn-danger btn-sm" data-id="'.$val->plot_detail_id .'" href="'.base_url().'Add_booked_plots/'.$val->plot_detail_id.'" style="border-radius: 25px;">Book Plot</a>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'booked_plot'){
        $table='tbl_booked_plot';
        $uniq_id = 'booked_plot_id';
        $status ='Booked';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        $data[] = array(
            $no++,
            $val->booked_plot_id,
            $property_name,
            $val->total_plot_extension,
            $val->buyer_name,
            '<a class="btn btn-success btn-sm" data-id="'.$val->booked_plot_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->booked_plot_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<a class="btn btn-info btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->booked_plot_id.'/pdf" ><i class="ri-file-pdf-2-fill"></i></a>'.' '.
            '<a class="btn btn-secondary btn-sm" href="'.base_url().'common/List_controller/export_list_pdf/'.$page_title.'/'.$val->booked_plot_id.'/print" ><i class="ri-printer-line"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->booked_plot_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'customer_info'){
        $table='tbl_customer_info';
        $uniq_id = 'customer_info_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {

        $data[] = array(
            $no++,
            $val->customer_info_id,
            $val->buyer_name,
            $val->district,
            $val->pincode,
            '<a class="btn btn-success btn-sm" data-id="'.$val->customer_info_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->customer_info_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->customer_info_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'staff_info'){
        $table='tbl_staff_info';
        $uniq_id = 'staff_info_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {

        $data[] = array(
            $no++,
            $val->staff_info_id,
            $val->employee_name,
            $val->father_name,
            $val->role,
            '<a class="btn btn-success btn-sm" data-id="'.$val->staff_info_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->staff_info_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->staff_info_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'add_offer'){
        $table='tbl_add_offer';
        $uniq_id = 'add_offer_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        $data[] = array(
            $no++,
            $val->add_offer_id,
            $property_name,
            $val->total_target,
            $val->offer,
            '<a class="btn btn-success btn-sm" data-id="'.$val->add_offer_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->add_offer_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->add_offer_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'offer_incentives'){
        $table='tbl_offer_incentives';
        $uniq_id = 'offer_incentives_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        $data[] = array(
            $no++,
            $val->offer_incentives_id,
            $property_name,
            $val->total_values,
            $val->incentive,
            '<a class="btn btn-success btn-sm" data-id="'.$val->offer_incentives_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->offer_incentives_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->offer_incentives_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'salary_advance'){
        $table='tbl_salary_advance';
        $uniq_id = 'adv_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $sql = $this->db->query("SELECT employee_name FROM tbl_staff_info WHERE staff_info_id = ?", array($val->employee_name));
            $employee_name = $sql->row();
            if ($employee_name) {
                $employee = $employee_name->employee_name;
            } else {
                $employee = 'Unknown Employee Nmae';
            }
            $date = new DateTime($val->adv_date);
            $adv_date = $date->format('d/m/Y');
        $data[] = array(
            $no++,
            $val->adv_id,
            $adv_date,
            $employee,
            $val->employee_id,
            $val->advance_amount,
            '<a class="btn btn-success btn-sm" data-id="'.$val->adv_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->adv_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->adv_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'employee_salary'){
        $table='tbl_employee_salary';
        $uniq_id = 'emp_salary_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $sql = $this->db->query("SELECT employee_name FROM tbl_staff_info WHERE staff_info_id = ?", array($val->employee_name));
            $employee_name = $sql->row();
            if ($employee_name) {
                $employee = $employee_name->employee_name;
            } else {
                $employee = 'Unknown Employee Nmae';
            }

        $data[] = array(
            $no++,
            $val->emp_salary_id,
            $employee,
            $val->advance_amount,
            $val->balance_amount,
            '<a class="btn btn-success btn-sm" data-id="'.$val->emp_salary_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->emp_salary_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->emp_salary_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else if(!empty($page_title) && $page_title == 'expense'){
        $table='tbl_expense_details';
        $uniq_id = 'expense_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
            $sql = $this->db->query("SELECT expen_name FROM tbl_expenses WHERE expen_id = ?", array($val->expense_type));
            $expense = $sql->row();
            if ($expense) {
                $expense_type = $expense->expen_name;
            } else {
                $expense_type = 'Unknown Expense Type';
            }
        $data[] = array(
            $no++,
            $val->expense_id,
            $property_name,
            $expense_type,
            $val->expense_value,
            '<a class="btn btn-success btn-sm" data-id="'.$val->expense_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->expense_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->expense_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }
    else if(!empty($page_title) && $page_title == 'billing_receipt'){
        $table='tbl_billing_receipt';
        $uniq_id = 'billing_receipt_id';
        $search_columns = $this->db->list_fields($table);
        // echo '<pre>';print_r($search_columns);die();
        $total_data1 = $this->list->total_property($search_value,$table,$uniq_id);
        $data1 = $this->list->get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns);

        $data = array();
        $no = 1; 
        foreach ($data1->result() as $val) {
            $query = $this->db->query("SELECT property_name FROM tbl_property WHERE property_id = ?", array($val->property_name));
            $property = $query->row();
            
            // Check if the property was found
            if ($property) {
                $property_name = $property->property_name;
            } else {
                $property_name = 'Unknown Property';
            }
        $data[] = array(
            $no++,
            $val->billing_receipt_id,
            $property_name,
            $val->company_name,
            $val->customer_name,
            '<a class="btn btn-success btn-sm" data-id="'.$val->billing_receipt_id.'" href="'.base_url().'Edit_'.$page_title.'/'.$val->billing_receipt_id.'" ><i class="ri-edit-box-fill"></i></a>'.' '.
            '<button type="button" class="btn btn-danger btn-sm confirm-color" onclick="delete_record('.$val->billing_receipt_id.')"><i class="ri-delete-bin-fill"></i></button>',
        );
        }

    }else{
       $total_data1 =''; 
       $data =''; 
    }
      

        $output = array(
        'draw' => $draw,
        'recordsTotal' => $total_data1,
        'recordsFiltered' => $total_data1, // Adjust this if you implement filtering logic
        'data' => $data
        );

        // Send JSON response to DataTables
        echo json_encode($output);
        exit();
    }
        
    public function delete_list_data() {
        $id = $this->input->post('id');
        $page_title = $this->input->post('title');

        // Debugging: Output received POST data
        log_message('debug', 'delete_list_data - ID: ' . $id . ' Title: ' . $page_title);

        $table = '';
        $uniq_id ='';
        
        if(!empty($page_title) && $page_title == 'Nager/Garden Profile'){
            $table='tbl_property';
            $uniq_id = 'property_id';
         }else if(!empty($page_title) && $page_title == 'Registered Plots'){
            $table='tbl_reg_plot';
            $uniq_id = 'reg_plot_id';
         }else if(!empty($page_title) && $page_title == 'Unregistered Plots'){
            $table='tbl_unreg_plot';
            $uniq_id = 'unreg_plot_id';
         }else if(!empty($page_title) && $page_title == 'Booked Plots'){
            $table='tbl_booked_plot';
            $uniq_id = 'booked_plot_id';
         }else if(!empty($page_title) && $page_title == 'Customer Details'){
            $table='tbl_customer_info';
            $uniq_id = 'customer_info_id';
         }else if(!empty($page_title) && $page_title == 'Staff Details'){
            $table='tbl_staff_info';
            $uniq_id = 'staff_info_id';
         }else if(!empty($page_title) && $page_title == 'Add Offer'){
            $table='tbl_add_offer';
            $uniq_id = 'add_offer_id';
         }else if(!empty($page_title) && $page_title == 'Offer Incentives'){
            $table='tbl_offer_incentives';
            $uniq_id = 'offer_incentives_id';
         }else if(!empty($page_title) && $page_title == 'Salary Advance'){
            $table='tbl_salary_advance';
            $uniq_id = 'adv_id';
         }else if(!empty($page_title) && $page_title == 'Employee Salary'){
            $table='tbl_employee_salary';
            $uniq_id = 'emp_salary_id';
         }else if(!empty($page_title) && $page_title == 'Expense Details'){
            $table='tbl_expense_details';
            $uniq_id = 'expense_id';
         }else if(!empty($page_title) && $page_title == 'Customer Receipt'){
            $table='tbl_billing_receipt';
            $uniq_id = 'billing_receipt_id';
         }
         
         if($table !='' && $uniq_id != ''){
            log_message('debug', 'delete_list_data - Deleting property with ID: ' . $id);
            $this->db->set('deleted', '1');
            $this->db->where($uniq_id, $id);
            $updated = $this->db->update($table);
            log_message('debug', 'delete_list_data - Update status: ' . $updated);
            $response = array('success' => (bool)$updated);
            echo json_encode($response);
        } else {
           
            log_message('debug', 'delete_list_data - Invalid title: ' . $page_title);

            $response = array('success' => false, 'message' => 'Invalid title');
            echo json_encode($response);
        }
    }


    //export Pdf

   
    public function export_list_pdf($title = NULL, $id = NULL,$type=NULL) {

    if (!empty($title) && $title == 'Property') {
        $title = 'NAGAR / GARDEN PROFILE';
        $data = $this->db->select('*')->where('property_id', $id)->get('tbl_property')->row_array();
        // Define static column names
       $columnNames = [
        'NAGAR /GARDEN NAME' => $data['property_name'],
        'PLOT NO' => $data['plot_no'],
        'DISTRICT' => $data['district'],
        'TALUK NAME' => $data['taluk_name'],
        'PLOT NO' => $data['plot_no'],
        'VILLAGE/TOWN' => $data['village_town'],
        'PATTA CHITTA NO' => $data['patta_chitta'],
        'TSNO' => $data['t_s_no'],
        'WARD / BLOCK' => $data['ward_block'],
        'LAND MARK' => $data['land_mark'],
        'DCTP NO' => $data['dctp_no'],
        'RERO NO' => $data['rero_no'],
        'TOTAL EXTENSION SQFT/SQMT' => $data['total_entension'],
        'TOTAL NO OF PLOTS' => $data['total_no_plots'],
        'PARK EXTENSION' => $data['park_extension'],
        'ROAD EXTENSION' => $data['road_extension'],
        'EB BILL' => ($data['eb_line'] == '1') ? 'YES': 'NO',
        'TREE SAPLING' => ($data['tree_sapling'] == '1') ? 'YES': 'NO',
        'WATER TANK' => ($data['water_tank'] == '1') ? 'YES': 'NO',
        'DOCUMENT REGISTER NO' =>$data['document_reg_no'],
        'LAND PURCHASE NO' => $data['land_purchased_no'],
        'REGISTER DISTRICT' => $data['reg_district'],
        'REGISTER TOWN/VILLAGE' => $data['reg_town_village'],
        'REGISTER SUB DISTRICT' => $data['reg_sub_district'],
        'REGISTER REVENUE TALUK' => $data['reg_revenue_taluk'],
        'SUB - REGISTER' =>$data['sub_reg'],
        'SALES EXTENSION' => $data['sales_extention'],
        'EAST' => $data['east'],
        'WEST' => $data['west'],
        'NORTH' =>$data['north'],
        'SOUTH' => $data['south'],
        'CREATED DATE' => date('d/m/Y',strtotime($data['created_at'])),
    ];

    }else if(!empty($title) && $title == 'reg_plot'){
        
        $title = 'SOLD / REGISTERED PLOT';
        $data = $this->db->select('A.*,B.property_name as property_name_str')->from('tbl_reg_plot as A')
        ->join('tbl_property as B','A.property_name = B.property_id')
        ->where('A.reg_plot_id', $id)->get()->row_array();
        // Define static column names
        // echo '<pre>';print_r($data);die();
       $columnNames = [
        'S NO' => $data['s_no'],
        'NAGAR /GARDEN NAME' => $data['property_name_str'],
        'PLOT NO' => $data['plot_no'],
        'TOTAL PLOT EXTENSION' => $data['total_plo_extension'],
        'BUYER NAME' => $data['buyer_gender'] .'.'.$data['buyer_name'],
        'FATHER NAME' => $data['father_rel'] .'.'.$data['father_name'],
        'PHONE NUMBER' => $data['phone_number'],
        'BUYER ADDRESS' => $data['buyer_address'],
        'EAST' => $data['east'],
        'WEST' => $data['west'],
        'NORTH' =>$data['north'],
        'SOUTH' => $data['south'],
        'ID PROOF' => $data['id_proof_select'],
        ucwords($data['id_proof_select'] .' NO') => $data['id_proof'],
        'PLOT REGISTER DOCUMENT NO' =>$data['plot_reg_doc_num'],
        'PLOT REGISTER DATE' =>(!empty($data['plot_reg_date']))  ? date('d/m/Y',strtotime($data['plot_reg_date'])) : '',
        'PATTA CHITTA NO' => $data['patta_chitta'],
        'TSNO' => $data['t_s_no'],
        'WARD / BLOCK' => $data['ward_block'],
        'PLOT RATE' => $data['plot_rate'],
        'MODE OF PAYMENT' => $data['mode_payment'],
        ucwords($data['mode_payment'] .' NO') => $data['mode_payment_value'],
        'REFER BY' => $data['name_ref_by'],
        'ALTERNATIVE PHONE NUMBER' => $data['alt_phone_number'],
        'REGISTER DISTRICT' => $data['reg_district'],
        'REGISTER TOWN/VILLAGE' => $data['reg_town_village'],
        'REGISTER SUB DISTRICT' => $data['reg_sub_district'],
        'REGISTER REVENUE TALUK' => $data['reg_revenue_taluk'],
        'SUB - REGISTER' =>$data['sub_reg'],        
        'CREATED DATE' => date('d/m/Y',strtotime($data['created_date'])),
    ];

    }else if(!empty($title) && $title == 'booked_plot'){
        
        $title = 'BOOKED PLOT';
        $data = $this->db->select('A.*,B.property_name as property_name_str')->from('tbl_booked_plot as A')
        ->join('tbl_property as B','A.property_name = B.property_id')
        ->where('A.booked_plot_id', $id)->get()->row_array();
        // Define static column names
        // echo '<pre>';print_r($data);die();
       $columnNames = [
        'S NO' => $data['s_no'],
        'NAGAR /GARDEN NAME' => $data['property_name_str'],
        'PLOT NO' => $data['plot_no'],
        'TOTAL PLOT EXTENSION' => $data['total_plot_extension'],
        'BUYER NAME' => $data['buyer_gender'] .'.'.$data['buyer_name'],
        'FATHER NAME' => $data['father_rel'] .'.'.$data['father_name'],
        'PHONE NUMBER' => $data['phone_number'],
        'BUYER ADDRESS' => $data['buyer_address'],
        'EAST' => $data['east'],
        'WEST' => $data['west'],
        'NORTH' =>$data['north'],
        'SOUTH' => $data['south'],
        'ID PROOF' => $data['id_proof_select'],
        ucwords($data['id_proof_select'] .' NO') => $data['id_proof'],
        'ADVANCE AMOUNT FOR PLOT' =>$data['adv_amount_plot'],
        'BALANCE AMOUNT FOR PLOT' => $data['bal_amount_for_plot'],
        'TENTATIVE REGISTER DATE' =>(!empty($data['tentative_reg_date']))  ? date('d/m/Y',strtotime($data['tentative_reg_date'])) : '',
        'MODE OF PAYMENT' => $data['mode_payment'],
        ucwords($data['mode_payment'] .' NO') => $data['mode_payment_value'],
        'REFER BY' => $data['name_ref_by'],
        'ALTERNATIVE PHONE NUMBER' => $data['alt_phone_number'],      
        'CREATED DATE' => date('d/m/Y',strtotime($data['created_date'])),
    ];

    }

    $this->tcpdf->SetCreator(PDF_CREATOR);
    $this->tcpdf->SetTitle($title);
    // Remove default header
    $this->tcpdf->setPrintHeader(false);

    // Add a page
    $this->tcpdf->AddPage();

    // Set font for title
    $this->tcpdf->SetFont('times', 'B', 16);
    $this->tcpdf->Cell(0, 10, $title, 0, 1, 'C'); // Centered title

    // Set font for table headers
    $this->tcpdf->SetFont('times', 'B', 10);

    // Set column width
    $colWidth = 90;

    // Add table rows dynamically
    foreach ($columnNames as $columnName => $dbField) {
        $this->tcpdf->Cell($colWidth, 10, $columnName, 1, 0, 'L'); // Column name
        $this->tcpdf->SetFont('times', '', 10); // Set font to normal for values
        $this->tcpdf->Cell($colWidth, 10, $dbField, 1, 1, 'R'); // Corresponding value
        $this->tcpdf->SetFont('times', 'B', 10); // Reset font to bold for the next column name
    }

    if($type == "pdf"){
    // Output the PDF with 'D' option to prompt download
    $this->tcpdf->Output(''.$title.'_' . date('Ymd_His') . '.pdf', 'D');
    }else{
    // Output the PDF with 'D' option to prompt download
    $this->tcpdf->Output(''.$title.'_' . date('Ymd_His') . '.pdf', 'I');
    }
    
}

}