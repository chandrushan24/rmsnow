<?php

class Common_Model extends CI_Model
{

    public function save($table,$data)
    {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    
    public function getall_record_info($table)
    {
        $this->db->select('*');
        $this->db->from($table);
        $info = $this->db->get();
        return $info->result();
    }

    public function getall_record_info_array($table)
    {
        $this->db->select('*');
        $this->db->from($table);
        $info = $this->db->get();
        return $info->result_array();
    }
    
    public function getall_record_info_with_deletedCheck_array($table)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('deleted',0);
        $info = $this->db->get();
        return $info->result_array();
    }   

    public function getall_record_info_with_deletedCheck_with_id_array($table,$column,$id)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($column, $id);
        $this->db->where('deleted',0);
        $info = $this->db->get();
        return $info->result_array();
    }

    public function getall_record_info_with_detail_with_two_id_array($table,$column,$id,$column1,$id1)
    {
            // Convert the comma-separated string to an array
    $id1 = explode(',', $id1);

    // Trim quotes from each status value
    $id1 = array_map(function($value) {
        return trim($value, '"\'');
    }, $id1);
    
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($column, $id);
        $this->db->where_in($column1, $id1);
        $this->db->where('deleted',0);
        $info = $this->db->get();
        // echo $this->db->last_query(); die;
        return $info->result_array();
    }

    public function get_single_date($table,$column,$id)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($column, $id);
        $info = $this->db->get();
        return $info->row_array();
    }

    public function update_info($table,$data,$column ,$id)
    {
        $this->db->where($column, $id);
        return $this->db->update($table, $data);
    }


   
    function get_media_img($tbl_media_type = '',$tbl_module_id ='', $isfeature='', $status = ''){
        $this->db->select('*');
        if($tbl_media_type != ''){
            $this->db->where('tbl_media_type', $tbl_media_type);
        }
        if($tbl_module_id != ''){
            $this->db->where('tbl_module_id', $tbl_module_id);
        }
        if($isfeature != ''){
            $this->db->where('tbl_featured_img',$isfeature );
        }
        if($status != ''){
            $this->db->where('publication_status',$status );
        }


        $this->db->order_by('order_', 'ASC');

        $this->db->from('tbl_media');
        $info = $this->db->get();
        return $info->result_array();
    }

    function get_media_img_row($tbl_media_type = '',$tbl_module_id ='', $isfeature='', $status = ''){
        $this->db->select('*');
        if($tbl_media_type != ''){
            $this->db->where('tbl_media_type', $tbl_media_type);
        }
        if($tbl_module_id != ''){
            $this->db->where('tbl_module_id', $tbl_module_id);
        }
        if($isfeature != ''){
            $this->db->where('tbl_featured_img',$isfeature );
        }
        if($status != ''){
            $this->db->where('publication_status',$status );
        }


        $this->db->order_by('order_', 'ASC');

        $this->db->from('tbl_media');
        $info = $this->db->get();
        return $info->row_array();
    }


    function save_upload_img($module_type,$module_id,$path,$media){
        if(empty($media['next_order'])){
            $media['next_order'] = 1;
        }
        $data = array();
        $data['tbl_media_type'] = $module_type;
        $data['tbl_module_id'] = $module_id;
        $data['tbl_orig_name'] = $media['orig_name'];
        $data['tbl_client_name'] = $media['client_name'];
        $data['tbl_file_path'] = $path.$media['orig_name'];
        $data['tbl_file_ext'] = $media['file_ext'];
        $data['order_'] = $media['next_order'];
        // print_r($data); die;
        $this->db->insert('tbl_media', $data);
    }

    
    public function delete_info($table,$column,$id)
    {
        $this->db->where($column, $id);
        return $this->db->delete($table);
    }


    public function search_customers($term) {
        if(!empty($term)){
        $this->db->like('buyer_name',  $term);
        $this->db->where('deleted',0);
        $query = $this->db->get('tbl_customer_info');
        $results = $query->result_array();

        $data = [];
        foreach ($results as $row) {
            $data[] = [
                'id' => $row['customer_info_id'],
                'value' => $row['buyer_name'],
                'street_address' => $row['street_address'],
                'id_proof_select' => $row['id_proof_select'],
                'id_proof' => $row['id_proof'],
                'phone_number_1' => $row['phone_number_1'],
                'id_proof' => $row['id_proof'],
                'father_name' => $row['father_name'],
                'father_rel' => $row['father_rel'],
                'buyer_gender' => $row['buyer_gender'],
            ];
        }

        return $data;
    }
}

    public function add_or_get_customer_id($customerName) {
        if(!empty($customerName)){
        $this->db->where('buyer_name', $customerName);
        $query = $this->db->get('tbl_customer_info');
        
        if ($query->num_rows() > 0) {
            return $query->row()->customer_info_id;
        } else {
            $data = ['buyer_name' => $customerName];
            $this->db->insert('tbl_customer_info', $data);
            return $this->db->insert_id();
        }
    }
}


}
