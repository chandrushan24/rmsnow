<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Settings_model','set');
        

    }
	public function index()
	{
		$this->load->view('login'); 
	}
	public function dashboard()
	{
		$this->render_page('welcome_message'); 
	}
	public function authenticate() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->set->login($username, $password);
        $company = $this->set->company($user->comid);
        if ($user) {
            $user_data = array(
                'userid' => $user->headerid,
                'username' => $user->username,
                'role' => $user->type,
                'comp_id' => $user->comid,
                'logo' => $company->logopath,
                'logged_in' => TRUE
            );
            $this->session->set_userdata($user_data);
            redirect('Dashboard');
        } else {
            $this->session->set_flashdata('error', 'Invalid username or password');
			redirect(base_url());
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url());
    }
	
}
