<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Billing_receipt_controller extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }
    public function index()
	{
        $data                 = array();
        
        $data['title'] = 'Billing Receipt';
        $data['propert_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_property');
        $data['customer_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_customer_info');
        $company_id = $this->session->userdata('comp_id');
        $data['company_data'] = $this->common_model->get_single_date('company','comid',$company_id);

        
		$this->render_page('admin/billing/billing_receipt',$data); 
	}


    public function edit($id = NULL)
	{
        $data                 = array();
        
        $data['title'] = 'Billing Receipt';
        if($id){
            $data['get_prop'] = $this->common_model->get_single_date('tbl_billing_receipt','billing_receipt_id',$id);
        }
        $data['propert_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_property');
        $data['customer_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_customer_info');

		$this->render_page('admin/billing/edit_billing_receipt',$data); 
	}


    public function save_billing_receipt()
    {
        $data                         = array();
        $billing_receipt_id  = $this->input->post('billing_receipt_id');
        $data['property_name'] =$this->input->post('property_name_input');
        $data['company_name'] =$this->input->post('company_name_input');
        $data['bill_id'] =$this->input->post('bill_id_input');
        $data['date_time'] =$this->input->post('date_time_input');
        $data['customer_name'] =$this->input->post('customer_name_input');
        $data['father_rel'] =$this->input->post('father_rel_input');
        $data['father_name'] =$this->input->post('father_name_input');
        $data['plot_no'] =$this->input->post('plot_no_input');
        $data['plot_extension'] =$this->input->post('plot_extension_input');
        $data['adv_amount_plot'] =$this->input->post('adv_amount_plot_input');
        $data['mode_payment'] =$this->input->post('mode_payment_input');
        $data['mode_payment_value'] =$this->input->post('mode_payment_value_input');
        $data['phone_number'] =$this->input->post('phone_number_input');
        $data['address'] =$this->input->post('address_input');
        $data['comp_address'] =$this->input->post('comp_address_input');
        

        $data['user_id'] =$this->session->userdata('userid');
        $data['company_id'] = $this->session->userdata('comp_id');
        
        if($billing_receipt_id == ''){
            $billing_receipt_id = $this->common_model->save('tbl_billing_receipt',$data);
            $status = 'Inserted';
        }else{
            $this->common_model->update_info('tbl_billing_receipt',$data,'billing_receipt_id',$billing_receipt_id);
            $status = 'Updated';
        }

        if ($billing_receipt_id) {
         $page_name = "Billing Receipt";
         
         $response = array('status' => 'success', 'message' => $page_name . ' '.$status.'  Successfully');
    
        } else {
            $response = array('status' => 'error', 'message' => $page_name . ' '.$status.'  Failed');
        }
        
        echo json_encode($response);
        return;
    }

}