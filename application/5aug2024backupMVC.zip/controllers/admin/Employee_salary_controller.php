<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_salary_controller extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }
    public function index($id = NULL)
	{
        $data                 = array();
        
        $data['title'] = 'Employee Salary';
        if($id){
            $data['get_prop'] = $this->common_model->get_single_date('tbl_employee_salary','emp_salary_id',$id);
        }
        $data['employee_list'] = $this->common_model->getall_record_info_with_deletedCheck_array('tbl_staff_info');
            
		$this->render_page('admin/billing/employee_salary',$data); 
	}

    public function save_employee_salary_details()
    {
        $data                         = array();
        $emp_salary_id   = $this->input->post('emp_salary_id');
        $data['company_id'] = $this->session->userdata('comp_id');
        $data['employee_name'] =$this->input->post('employee_name_input');
        $data['employee_id'] =$this->input->post('employee_id_input');
        $data['net_salary_amount'] =$this->input->post('net_salary_amount_input');
        $data['advance_amount'] =$this->input->post('advance_amount_input');
        $data['balance_amount'] =$this->input->post('balance_amount_input');
        $data['user_id'] =$this->session->userdata('userid');

        if($emp_salary_id == ''){
            $emp_salary_id = $this->common_model->save('tbl_employee_salary',$data);
            $status = 'Inserted';
        }else{
            $this->common_model->update_info('tbl_employee_salary',$data,'emp_salary_id',$emp_salary_id);
            $status = 'Updated';
        }
        if ($emp_salary_id) {
           
            $page_name = "Employee Salary";

            $response = array('status' => 'success', 'message' => $page_name . ' '.$status.'  Successfully');

            } else {
                $response = array('status' => 'error', 'message' => $page_name . ' '.$status.'  Failed');
            }
            
            echo json_encode($response);
            return;

    }
   public function get_sal_adv_data(){
        $emp_id = $this->input->get('emp_id');
        $this->db->select_sum('advance_amount');
        $this->db->from('tbl_salary_advance');
        $this->db->where('employee_name', $emp_id);
        $this->db->where('salary_id IS NULL', null, false);
        $this->db->where('deleted', '0');
        $query = $this->db->get();
        $data = $query->row()->advance_amount;
        echo json_encode($data);
        return;
    }


}