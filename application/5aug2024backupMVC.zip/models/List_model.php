<?php

class List_model extends CI_Model
{
   public function total_property($search_value,$table,$uniq_id){

            $this->db->select("COUNT(DISTINCT ".$uniq_id.") AS total_rows");
            $this->db->from($table);
            $this->db->where('deleted', '0');
            $query = $this->db->get();
            $result = $query->row();
            return ($result) ? $result->total_rows : 0;
   }
   public function get_property($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns){
                $this->db->select('*');
                $this->db->from($table);
                if (!empty($search_value)) {
                $this->db->group_start();
                foreach($search_columns as $index => $val){
                if ($index == 0) {
                    $this->db->like($val, $search_value, 'both');
                } else {
                    $this->db->or_like($val, $search_value, 'both');
                }
                }
                $this->db->group_end();
                }
                $this->db->where('deleted', '0');
                $this->db->order_by($uniq_id, 'DESC');
                $this->db->limit($length, $start);
                $this->db->group_by($uniq_id);
                $query = $this->db->get();
                return $query;
           
   }

   public function total_property_details($search_value,$table,$uniq_id,$status){

    $this->db->select("COUNT(DISTINCT ".$uniq_id.") AS total_rows");
    $this->db->from($table);
    $this->db->where('deleted', '0');
    $this->db->where_in('status', $status);
    $query = $this->db->get();
    $result = $query->row();
    return ($result) ? $result->total_rows : 0;
   }
   public function get_property_details($start, $length,$sort,$search_value,$table,$uniq_id,$search_columns,$status){
        $this->db->select('*');
        $this->db->from($table);
        if (!empty($search_value)) {
        $this->db->group_start();
        foreach($search_columns as $index => $val){
        if ($index == 0) {
            $this->db->like($val, $search_value, 'both');
        } else {
            $this->db->or_like($val, $search_value, 'both');
        }
        }
        $this->db->group_end();
        }
        $this->db->where_in('status', $status);
        $this->db->where('deleted', '0');
        $this->db->order_by($uniq_id, 'DESC');
        $this->db->limit($length, $start);
        $this->db->group_by($uniq_id);
        $query = $this->db->get();
        return $query;
    }
}
