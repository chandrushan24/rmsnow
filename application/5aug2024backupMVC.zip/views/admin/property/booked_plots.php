
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?=base_url()?>/assets/vendor/libs/flatpickr/flatpickr.css" />
    <script src="<?=base_url()?>/assets/vendor/libs/flatpickr/flatpickr.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
 
    <!-- Content wrapper -->
    <div class="content-wrapper">


<!-- Content -->

  <div class="container-xxl flex-grow-1 container-p-y">
    

<!-- Multi Column with Form Separator -->
       <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url('booked_plot') ?>"><?php echo $title; ?> </a></li> /
                <li class=""><a href="javascript:void(0)"><?php if(!isset($get_prop)){echo 'Add  ';}else{echo 'Edit ';} echo $title;?></a></li>
            </ol>
        </div>
<div class="card">
  <h5 class="card-header"><?php if(!isset($get_prop)){echo 'Add  ';}else{echo 'Edit ';} echo $title;?></h5>
  <hr class="my-4" />

  <form id="myForm" class="card-body" method="post" enctype="multipart/form-data" onSubmit="return false">
    <div class="row g-6">
      <div class="col-md-4">
        <div class="form-floating form-floating-outline">
          <input type="text" id="multicol-s_nos" class="form-control" name="s_no_inputs"  value="<?php if(isset($get_prop)){echo $get_prop['s_no'];}else{echo $get_seq_no;}?>" placeholder="Enter S.No" disabled/>
          <input type="hidden" name="s_no_input" id="multicol-s_no" value="<?php if(isset($get_prop)){echo $get_prop['s_no'];}else{echo $get_seq_no;}?>">
          <input type="hidden" name="seqno" id="seqno" value="<?php if(isset($seq_no)){echo $seq_no;}?>">
          <input type="hidden" class="form-control" name="customer_id" value="<?php if(isset($get_prop)){echo $get_prop['customer_id'];}?>" />

          <input type="hidden" class="form-control" name="booked_plot_id" value="<?php if(isset($get_prop)){echo $get_prop['booked_plot_id'];}?>" />
          <label for="multicol-confirm-s_no">S.No</label>
        </div>
      </div>
     
      <div class="col-md-4">
        <div class="form-floating form-floating-outline">
          <select  class="select2 form-select" id="property_name_input" name="property_name_input" data-allow-clear="true">
          <option value="" selected disabled>Select Nager / Garden</option>
          <?php if(!empty($propert_list)){ 
            $selected = '';
            foreach($propert_list as $val){ 
            if(isset($get_prop)){
              if($get_prop['property_name'] == $val['property_id']){
                $selected = 'selected';
              }else{
                $selected = '';
              }
            }else if(isset($get_prop_)){
              if($get_prop_['property_id'] == $val['property_id']){
                $selected = 'selected';
              }else{
                $selected = '';
              }
            }
            ?>
            <option value="<?php echo $val['property_id'];?>"  <?php echo $selected;?> ><?php echo $val['property_name'];?></option>
            <?php } ?>
           <?php } ?>
          </select>
          <label for="multicol-state">Select Nagar/Garden Name</label>
        </div>
      </div>

      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
          <select  class="select2 form-select" id="plot_no_input" name="plot_no_input" data-allow-clear="true" data-plot="<?php if(isset($get_prop)){echo $get_prop['plot_no'];}else if(isset($get_prop_)){echo $get_prop_['plot_detail_id'];}?>" >
          </select>
              <label for="multicol-confirm-plot_no">Plot No</label>
            </div>
          </div>
      </div>
      
      <!-- <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-plot_no" class="form-control"  name="plot_no_input" value="<?php if(isset($get_prop)){echo $get_prop['plot_no'];}?>"  placeholder="Enter Plot No"  />
              <label for="multicol-confirm-plot_no">Plot No</label>
            </div>
          </div>
      </div> -->

      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-total_plo_extension" class="form-control" name="total_plot_extension_input" value="<?php if(isset($get_prop)){echo $get_prop['total_plot_extension'];}?>" placeholder="Enter Total Plot Extension in Sqft/Sqmt"  />
              <label for="multicol-confirm-total_plo_extension">Total Plot Extension in Sqft/Sqmt</label>
            </div>
          </div>
      </div>
        <div class="col-md-4">
                <div class="form-floating form-floating-outline">
                  <input type="text" id="formtabs-birthdate" class="form-control dob-picker" name="tentative_reg_date_input" value="<?php if(isset($get_prop)){echo $get_prop['tentative_reg_date'];}?>" placeholder="YYYY-MM-DD" />
                  <label for="formtabs-birthdate">Tentative Registration Date</label>
                </div>
              </div>

              
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
          <select id="name_ref_by_input" class="select2 form-select" name="name_ref_by_input[]" data-allow-clear="true" multiple>
          <?php if(!empty($all_employees)){
          foreach($all_employees as $val){
            $selected='';
            if(isset($get_prop)){
              if(!empty($get_prop['name_ref_by'])){
              $explode_value =explode(',',$get_prop['name_ref_by']);
             if(in_array($val['staff_info_id'],$explode_value)){
             $selected='selected';
             }
            }
            }
             ?>

            <option value="<?php echo $val['staff_info_id'];?>"  <?php echo $selected;?> ><?php echo $val['employee_name'];?> / <?php echo $val['role'];?></option>
            <?php  }?>
            <?php  }?>
          </select>
          <label for="multicol-state">Name Refered By</label>
        </div>
      </div>
      </div>

      <!-- <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-name_ref_by" class="form-control" name="name_ref_by_input" value="<?php if(isset($get_prop)){echo $get_prop['name_ref_by'];}?>" placeholder="Enter Name Refered By"  />
              <label for="multicol-confirm-name_ref_by">Name Refered By</label>
            </div>
          </div>
      </div> -->

      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-phone_number" class="form-control" name="alt_phone_number_input" value="<?php if(isset($get_prop)){echo $get_prop['alt_phone_number'];}?>" placeholder="Enter Phone Number"  />
              <label for="multicol-confirm-phone_number">Alternative Phone Number</label>
            </div>
          </div>
      </div>

      <!-- <hr> -->
      <h6 class="text-center bg-primary p-2 text-white">Customer Details</h6>
      <div class="col-md-4">
            <div class="input-group">
                <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="buyer_gender_display"><?php if(isset($get_prop)){echo $get_prop['buyer_gender'];}?></button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="javascript:void(0);" onclick="updateButtonText(this)">Mr</a></li>
                    <li><a class="dropdown-item" href="javascript:void(0);" onclick="updateButtonText(this)">Mrs</a></li>
                </ul>
                <input type="text"  id="buyer_name_input" class="form-control" aria-label="Text input with dropdown button" name="buyer_name_input" value="<?php if(isset($get_prop)){echo $get_prop['buyer_name'];}?>" placeholder="Enter Plot Buyer Name">
                <input type="hidden"  id="buyer_gender_input" name="buyer_gender_input" value="<?php if(isset($get_prop)){echo $get_prop['buyer_gender'];}?>">
            </div>
        </div>

       <div class="col-md-4">
      <div class="input-group">
          <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="father_rel_display"><?php if(isset($get_prop)){echo $get_prop['father_rel'];}?></button>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="javascript:void(0);" onclick="updateButtonText_1(this)">s/o</a></li>
            <li><a class="dropdown-item" href="javascript:void(0);" onclick="updateButtonText_1(this)">w/o</a></li>
          </ul>
          <input type="hidden"  id="father_rel_input" name="father_rel_input" value="<?php if(isset($get_prop)){echo $get_prop['father_rel'];}?>">
          <input type="text" class="form-control"  name="father_name_input" aria-label="Text input with dropdown button" value="<?php if(isset($get_prop)){echo $get_prop['father_name'];}?>" placeholder="Father Name">
        </div>
        </div>

        <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-phone_number" class="form-control" name="phone_number_input" value="<?php if(isset($get_prop)){echo $get_prop['phone_number'];}?>" placeholder="Enter Phone Number"  />
              <label for="multicol-confirm-phone_number">Phone Number</label>
            </div>
          </div>
      </div>
      
      <div class="col-md-4">
      <div class="input-group input-group-merge">
          <div class="form-floating form-floating-outline">
            <textarea class="form-control h-px-75" aria-label="With textarea" name="buyer_address_input" placeholder="Enter Buyer Address"><?php if(isset($get_prop)){echo $get_prop['buyer_address'];}?></textarea>
            <label>Buyer Address</label>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-floating form-floating-outline">
          <select  class="select2 form-select" id="id_proof_select_input" name="id_proof_select_input" data-allow-clear="true">
          <option value="" selected disabled>Select Proof</option>
          <option value="Aadhar"  <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Aadhar'){ echo 'selected';}else{ echo '';} }else{echo 'selected';}?>>Aadhar</option>
          <option value="Voter ID" <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Voter ID'){ echo 'selected';}else{ echo '';} }?>>Voter ID</option>
          <option value="Passport" <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Passport'){ echo 'selected';}else{ echo '';} }?>>Passport</option>
          <option value="Pancard" <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Pancard'){ echo 'selected';}else{ echo '';} }?>>Pancard</option>
          <option value="Driving License" <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Driving License'){ echo 'selected';}else{ echo '';} }?>>Driving License</option>
          <option value="Smart Card" <?php if(isset($get_prop)){if($get_prop['id_proof_select'] == 'Smart Card'){ echo 'selected';}else{ echo '';} }?>>Smart Card</option>
          </select>
          <label for="multicol-state">Id Proof</label>
        </div>
      </div>

      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" class="form-control" id="id_proof_input" name="id_proof_input" value="<?php if(isset($get_prop)){echo $get_prop['id_proof'];}?>" placeholder="Enter Aadhar No"  />
              <label for="multicol-confirm-plot_reg_doc_num" id="proof_label">Aadhar</label>
            </div>
          </div>
      </div>
      <!-- <hr> -->
      <h6 class="text-center bg-primary p-2 text-white">Plot Details</h6>
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-east_input" class="form-control" name="east_input" value="<?php if(isset($get_prop)){echo $get_prop['east'];}?>" placeholder="Enter East"  />
              <label for="multicol-confirm-east_input">East</label>
            </div>
          </div>
      </div>
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-west" class="form-control" name="west_input" value="<?php if(isset($get_prop)){echo $get_prop['west'];}?>" placeholder="Enter West"  />
              <label for="multicol-confirm-west">West</label>
            </div>
          </div>
      </div>
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-north" class="form-control" name="north_input" value="<?php if(isset($get_prop)){echo $get_prop['north'];}?>" placeholder="Enter North"  />
              <label for="multicol-confirm-north">North</label>
            </div>
          </div>
      </div>
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-South" class="form-control" name="south_input" value="<?php if(isset($get_prop)){echo $get_prop['south'];}?>" placeholder="Enter South"  />
              <label for="multicol-confirm-South">South</label>
            </div>
          </div>
      </div>

      <!-- <hr> -->
      <h6 class="text-center bg-primary p-2 text-white">Payment Details</h6>
      
      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-adv_amount_plot_input" class="form-control" name="adv_amount_plot_input" value="<?php if(isset($get_prop)){echo $get_prop['adv_amount_plot'];}?>" placeholder="Enter Advance Amount for Plot"  />
              <label for="multicol-confirm-adv_amount_plot_input">Advance Amount for Plot</label>
            </div>
          </div>
      </div>

      <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" id="multicol-bal_amount_for_plot_input" class="form-control" name="bal_amount_for_plot_input" value="<?php if(isset($get_prop)){echo $get_prop['bal_amount_for_plot'];}?>" placeholder="Enter Balance Amount for Plot"  />
              <label for="multicol-confirm-bal_amount_for_plot_input">Balance Amount for Plot</label>
            </div>
          </div>
      </div>
      <div class="col-md-4">
        <div class="form-floating form-floating-outline">
          <select  class="select2 form-select" id="mode_payment_input" name="mode_payment_input" data-allow-clear="true">
          <option value="" selected disabled>Select Payment Type</option>
          <option value="Cash" <?php if(isset($get_prop)){if($get_prop['mode_payment'] == 'Cash'){ echo 'selected';}else{ echo '';} }else{echo 'selected';}?>>Cash</option>
          <option value="Cheque" <?php if(isset($get_prop)){if($get_prop['mode_payment'] == 'Cheque'){ echo 'selected';}else{ echo '';} }?>>Cheque</option>
          <option value="UPI" <?php if(isset($get_prop)){if($get_prop['mode_payment'] == 'UPI'){ echo 'selected';}else{ echo '';} }?>>UPI</option>
          <option value="NEFT" <?php if(isset($get_prop)){if($get_prop['mode_payment'] == 'NEFT'){ echo 'selected';}else{ echo '';} }?>>NEFT</option>
          </select>
          <label for="multicol-state">Mode of Payement</label>
        </div>
      </div>

     <div class="col-md-4">
          <div class="input-group input-group-merge">
            <div class="form-floating form-floating-outline">
              <input type="text" class="form-control" id="mode_payment_value_input" name="mode_payment_value_input" value="<?php if(isset($get_prop)){echo $get_prop['mode_payment_value'];}?>" placeholder="Enter Amount"  />
              <label for="multicol-confirm-mode_payment_value_input" id="mode_pay_label">Cash</label>
            </div>
          </div>
      </div>

      </div>
<hr>
    <div class="pt-6">
      <button type="submit" id="submitBtn" class="btn btn-primary me-4">Submit</button>
      <a href="<?= base_url('booked_plot') ?>" class="btn btn-outline-danger me-4">Back</a>
    </div>
    </div>
  </form>
<!-- </div>
</div>
</div> -->



<!-- end table -->
</div>

          </div>
          <!-- / Content -->
 <!-- Page JS -->
 <script src="<?=base_url()?>/assets/js/extended-ui-sweetalert2.js"></script>
 <script src="<?=base_url()?>/assets/vendor/libs/sweetalert2/sweetalert2.js"></script>
 <script src="<?=base_url()?>/assets/js/form-layouts.js"></script>
  <script src="<?=base_url()?>/assets/vendor/libs/dropzone/dropzone.js"></script>
  <script>
    
  $(document).ready(function() {
         $(".prop").addClass("open");
         $(".booked_plot").addClass("active");

           // ********select 2 ***************
       var o = $("#property_name_input");
        select2Focus(o);
        o.wrap('<div class="position-relative"></div>');
        o.select2({ placeholder: "Select Nagar / Garden", dropdownParent: o.parent() });
  // ********select 2 ***************

    // ********select 2 ***************
    var o = $("#id_proof_select_input");
        select2Focus(o);
        o.wrap('<div class="position-relative"></div>');
        o.select2({ placeholder: "Select Proof", dropdownParent: o.parent() });
  // ********select 2 ***************
 
  // ********select 2 ***************
  var o = $("#mode_payment_input");
        select2Focus(o);
        o.wrap('<div class="position-relative"></div>');
        o.select2({ placeholder: "Select Payment Type", dropdownParent: o.parent() });
  // ********select 2 ***************

      // ********select 2 ***************
      var o = $("#plot_no_input");
      select2Focus(o);
      o.wrap('<div class="position-relative"></div>');  
      o.select2({ placeholder: "Select Plot No", dropdownParent: o.parent() });
      // ********select 2 ***************
      var o = $("#name_ref_by_input");
        select2Focus(o);
        o.wrap('<div class="position-relative"></div>');
        o.select2({ placeholder: "Select Team", dropdownParent: o.parent() });
  // ********select 2 ***************
  


  // +++++++++++++++Start ++++++++++++++++++
  // ____________________________________


   
        var property = $('#property_name_input').val();
      var check_redirect = '<?= isset($get_prop_) ? "true" : "false" ?>';  
      get_plot_details(property);
     
      if(check_redirect == 'true'){
      // get_plot_details(property);
      get_garden_nagar_details(property);
        // $('#plot_no_input').trigger('change');

      //  get_plot_details(property);
      }

      $('#property_name_input').on('change',function() {
      const property_id =$(this).val();
      get_garden_nagar_details(property_id);
      get_plot_details(property_id);
      });

      //plot extension

      $('#plot_no_input').on('change',function() {
      var det_id = $(this).val();
      get_plot_details_id(det_id);
      });

      // autocomplte


      function get_garden_nagar_details(property_id){
        if(property_id !='' && property_id !=null){
      $.ajax({
      url: '<?=base_url()?>admin/unregistered_plots_controller/get_property_details?property_id='+property_id,
      type: 'GET',
      processData: false,  
      contentType: false, 
      dataType: 'json',  
      success: function(response) {
        
        var staff_id = response.staff_id;
        var TeamArray = staff_id.split(',');
      // Set the values to the select element
      $("#name_ref_by_input").val(TeamArray);

      // Trigger the change event
      $("#name_ref_by_input").trigger('change');

      },
      error: function(xhr, status, error) {
      console.error('AJAX error:', status, error); // Log AJAX errors
      }
      });
      }
    }


      function get_plot_details(property_id){
        if(property_id !='' && property_id !=null){

      var detail_id = $('#plot_no_input').data('plot');
      var status = "UnSold";
      $.ajax({
        url: '<?=base_url()?>admin/unregistered_plots_controller/get_plot_details?property_id=' + property_id + '&status=' + status,
      type: 'GET',
      processData: false,  
      contentType: false,
      dataType: 'json',  
      success: function(response) {
        var html= ``;
        var selected = ``;
        html += `<option value="">Select Plot No</option>`;
        response.forEach(function(data){
        if(data.plot_detail_id == detail_id){ selected = `selected`;}else{ selected =``;}
        html += `<option value="${data.plot_detail_id}" ${selected}>${data.plot_no}</option>`;
        });

        $('#plot_no_input').html(html);
        
        if(check_redirect == 'true'){
        $('#plot_no_input').trigger('change');
        }

      },
      error: function(xhr, status, error) {
      console.error('AJAX error:', status, error); // Log AJAX errors
      }

      });
    }
  }

      function get_plot_details_id(det_id){
        if(det_id !='' && det_id !=null){
      $.ajax({
      url: '<?=base_url()?>admin/unregistered_plots_controller/get_single_plot_details?detail_id='+det_id,
      type: 'GET',
      processData: false,  
      contentType: false, 
      dataType: 'json',  
      success: function(response) {
        $("[name='total_plot_extension_input']").val(response.plot_extension);
        $("[name='east_input']").val(response.east);
        $("[name='west_input']").val(response.west);
        $("[name='north_input']").val(response.north);
        $("[name='south_input']").val(response.south);
        
      },
      error: function(xhr, status, error) {
      console.error('AJAX error:', status, error); // Log AJAX errors
      }

      });
    }
      }

      $(function() {
        $("#buyer_name_input").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "<?php echo base_url('admin/unregistered_plots_controller/autocomplete'); ?>",
                    dataType: "json",
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        response(data);
                    }
                });
            },
            select: function(event, ui) {
                console.log("Selected ID: " + ui.item.id);

                $("[name='buyer_address_input']").val(ui.item.street_address);
              $("[name='id_proof_select_input']").val(ui.item.id_proof_select).change();
              $("[name='id_proof_input']").val(ui.item.id_proof);
              $("[name='phone_number_input']").val(ui.item.phone_number_1);
              $("[name='customer_id']").val(ui.item.id);
              $("[name='father_name_input']").val(ui.item.father_name);
              $("[name='father_rel_input']").val(ui.item.father_rel);
              $("[name='buyer_gender_input']").val(ui.item.buyer_gender);
              $("#father_rel_display").html(ui.item.father_rel);
              $("#buyer_gender_display").html(ui.item.buyer_gender);
              
            }
        });

        $("#buyer_name_input").on('blur', function() {
            var customerName = $(this).val();
            $.ajax({
                url: "<?php echo base_url('admin/unregistered_plots_controller/add_customer'); ?>",
                type: "POST",
                data: { customerName: customerName },
                dataType: "json",
                success: function(data) {
                 $("[name='customer_id']").val(data.id);
                }
            });
        });
    });

    });
</script>
  <script>
    

$('.delete-image').on('click', function() {
    var id = $(this).attr('data-id');
    var module_id = $(this).attr('data-file');
    
    console.log(id);
    if (confirm('Are you sure to delete!')) {
        $.ajax({
            type: 'post',
            url: '<?php echo base_url('admin/property_controller/delete_img_ajax') ?>',
            data: {
                id: id,
                module_id: module_id
            },
            success: function(response) {
                    location.reload();
            }
        });
    }
});

function updateButtonText(element) {
    var button = element.closest('.input-group').querySelector('.btn.dropdown-toggle');
    button.textContent = element.textContent;
   document.getElementById('buyer_gender_input').value = element.textContent;
}

function updateButtonText_1(element) {
    var button = element.closest('.input-group').querySelector('.btn.dropdown-toggle');
    button.textContent = element.textContent;
   document.getElementById('father_rel_input').value = element.textContent;
}

$(document).ready(function() {

  var val_1 = $('#id_proof_select_input').val();
   var placeholter_str_1 = 'Enter '+ val_1 + ' No';
  $('#id_proof_input').attr('placeholder', placeholter_str_1);
   $('#proof_label').html(val_1);

// ----------------------------------

var val_pay =$('#mode_payment_input').val();

  if(val_pay == 'Cash' || val_pay == 'UPI'){
    var placeholter_str_pay = 'Enter '+ val_pay + ' Amount';
   }
   else{
    var placeholter_str_pay = 'Enter '+ val_pay + ' No';
   }

  $('#mode_payment_value_input').attr('placeholder', placeholter_str_pay);   
   $('#mode_pay_label').html(val_pay);

  //  ---------------------------------------


$('#id_proof_select_input').on('change', function() {
   var val=$(this).val();
   var placeholter_str = 'Enter '+ val + ' No';
  $('#id_proof_input').attr('placeholder', placeholter_str);
   $('#proof_label').html(val);
});

$('#mode_payment_input').on('change', function() {
   var val=$(this).val();
   if(val == 'Cash' || val == 'UPI'){
    var placeholter_str = 'Enter '+ val + ' Amount';
   }
   else{
    var placeholter_str = 'Enter '+ val + ' No';
   }

  $('#mode_payment_value_input').attr('placeholder', placeholter_str);   
   $('#mode_pay_label').html(val);
});


$('#submitBtn').on('click',function() {
          const form = document.querySelector('#myForm');
          const formData = new FormData(form); 
           $.ajax({
          url: '<?=base_url()?>admin/Booked_plots_controller/save_booked_plot',
          type: 'POST',
          data: formData,
          processData: false,  
          contentType: false, 
          dataType: 'json',  
          success: function(response) {
          console.log(response);

          if (response.status === 'success') {
              Swal.fire({
                  title: 'Success',
                  html: response.message,
                  icon: 'success'
              }).then((result) => {
              window.location.href = "<?= base_url('booked_plot'); ?>";
              }).catch((error) => {
                  console.error('Swal error:', error); // Log any errors with Swal
              });

              $(".swal2-deny").remove();
              $(".swal2-cancel").remove();
          } else {
              console.error('Unexpected status:', response.status); // Log unexpected status
          }
      },
      error: function(xhr, status, error) {
          console.error('AJAX error:', status, error); // Log AJAX errors
      }

        });

    });


});
   

</script>